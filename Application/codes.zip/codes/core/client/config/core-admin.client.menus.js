'use strict';

angular.module('core.admin').run(['Menus',
  function (Menus) {
        Menus.addMenuItem('topbar',
        {
            title: 'Home',
            state: 'home',
            roles:  ['*']
        }, {
            title: 'Admin',
            state: 'admin',
            type: 'dropdown',
            roles: ['admin']
        }, {
            title: 'Projects',
            state: 'projects',
            type: 'dropdown',
            roles: ['admin', 'member', 'payment']
        }, {
            title: 'Donations',
            state: 'donations',
            type: 'dropdown',
            roles: ['payment']
        });

  }
]);