'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

/**
 * Donation Schema
 */
var DonationSchema = new Schema({
  projectId: {
    type: Schema.ObjectId,
    ref: 'Project'
  },
  amount: {
    type: Number,
    default: '0.00',
    required: 'Please fill Donation amount',
    trim: true
  },
  created: {
    type: Date,
    default: Date.now
  },
  user: {
    type: Schema.ObjectId,
    ref: 'User'
  },
  
});

mongoose.model('Donation', DonationSchema);
