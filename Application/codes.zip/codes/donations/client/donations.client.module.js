(function (app) {
  'use strict';

  app.registerModule('donations',['ui.grid','ui.grid.infiniteScroll']);
}(ApplicationConfiguration));
