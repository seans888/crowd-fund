(function () {
  'use strict';

  angular
    .module('donations')
    .run(menuConfig);

  menuConfig.$inject = ['Menus'];

  function menuConfig(Menus) {
    // Set top bar menu items
    Menus.addMenuItem('topbar', {
      title: 'Donations',
      state: 'donations',
      type: 'dropdown',
      roles: ['admin']
    });

    // Add the dropdown list item
    Menus.addSubMenuItem('topbar', 'donations', {
      title: 'Project Contributors',
      state: 'donations.view',
      roles: ['admin']
    });
  }
}());
