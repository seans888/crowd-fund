(function () {
  'use strict';

  angular
    .module('donations')
    .controller('DonationsListController', DonationsListController);

  DonationsListController.$inject = ['DonationsService','$state', 'ProjectsService', '$filter', '$timeout'];

  function DonationsListController(DonationsService, $state, ProjectsService, $filter, $timeout) {
    var vm = this;
    vm.buildPager = buildPager;
    vm.figureOutItemsToDisplay = figureOutItemsToDisplay;
    vm.pageChanged = pageChanged;
    vm.returnToProj = returnToProj;
    vm.project={};
    vm.donations = DonationsService.query();
    var projId = $state.get('donations.list').data.projectId,
        donationsList = vm.donations,
    	  donationsArr = [],
        projectArr = [];

  	vm.donations.$promise.then(function(item){
  	  item.forEach(function(data){
  	    if(data.projectId !== undefined && data.projectId._id === projId) {
      		donationsArr.push(data);
          vm.project.pledged+=data.amount;
      	}
  	  });
  	});
    vm.donations = donationsArr;
    vm.projects =  ProjectsService.query({_id:projId});
    vm.projects.$promise.then(function(item){
      item.forEach(function(data){
        if(data._id === projId) {
            vm.project = data;
        }
      });
    });

    console.log(vm);

    

    $timeout(buildPager, 200);

    function buildPager() {
      vm.pagedItems = [];
      vm.itemsPerPage = 10;
      vm.currentPage = 1;
      figureOutItemsToDisplay();
    }

    function figureOutItemsToDisplay() {
      vm.filteredItems = $filter('filter')(vm.donations, {
        $: vm.search
      });
      vm.filterLength = vm.filteredItems.length;
      var begin = ((vm.currentPage - 1) * vm.itemsPerPage);
      var end = begin + vm.itemsPerPage;
      vm.pagedItems = vm.filteredItems.slice(begin, end);
    }

    function pageChanged() {
      figureOutItemsToDisplay();
    }

    function returnToProj(){
      $state.go('projects.view',{
        projectId: projId
      });
    }
  }
}());
