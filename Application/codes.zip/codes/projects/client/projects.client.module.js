(function (app) {
    'use strict';

    app.registerModule('projects', ['ui.bootstrap.datetimepicker', 'timer','swangular']);
}(ApplicationConfiguration));