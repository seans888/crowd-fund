(function () {
    'use strict';

    // Projects controller
    angular
        .module('projects')
        .controller('ProjectsController', ProjectsController);

    ProjectsController.$inject = ['$scope', '$state', '$window', 'Authentication', 'projectResolve', '$location', 'Admin', '$http', 'swangular', 'FileUploader', 'DonationsService', '$timeout'];

    function ProjectsController($scope, $state, $window, Authentication, project, $location, Admin, $http, swangular, FileUploader, DonationsService, $timeout) {
        var vm = this;

        vm.authentication = Authentication;
        vm.project = project;
        vm.error = null;
        vm.form = {};
        vm.remove = remove;
        vm.save = save;
        vm.endDateBeforeRender = endDateBeforeRender;
        vm.endDateOnSetTime = endDateOnSetTime;
        vm.startDateBeforeRender = startDateBeforeRender;
        vm.startDateOnSetTime = startDateOnSetTime;
        vm.viewContributors = viewContributors;
        vm.donation = {};
        vm.saveDonation = saveDonation;
        vm.roleAuth = roleAuth;
        vm.status = status;
        vm.imageURL = vm.project.picture;
        vm.project.user = vm.authentication.user;
        vm.project.pledged = 0;
        vm.pledge = 0;
        vm.project.payment = '';
        vm.showBank = false;
        vm.show = show;

        var donations = DonationsService.query({}),
            contributorsArr = [];

        if ($state.current.name == 'projects.process') {
            vm.project.$execute($state.params);
            $http.post('api/donations', vm.donation).
            success(function (response) {
                vm.contributorsCount += 1;
                swangular.swal("Donation successful!", "Thank you for donating", "success");
            });
        }

        donations.$promise.then(function (donation) {
            donation.forEach(function (data) {
                if (data.projectId !== undefined && data.projectId._id === vm.project._id) {
                    contributorsArr.push(data);
                    vm.project.pledged += data.amount;
                }
            });
        });

        $timeout(function () {
            vm.contributorsCount = contributorsArr.length;
        }, 150);

        moment.locale('en');

        if (vm.project.created && vm.project.expiration) {
            vm.startDate = moment(vm.project.created).format("YYYY-MM-DD");
            vm.endDate = moment(vm.project.expiration).format("YYYY-MM-DD");
        }

        function roleAuth(param) {
            var role = vm.authentication.user.roles;
            if (role.indexOf(param) > -1) {
                return true;
            }
        }

        function show() {
            $(".modal-backdrop").hide();
        }

        function status() {
            if (moment().isSame(vm.endDate) || moment().isAfter(vm.endDate)) {
                vm.project.status = 'Completed';
            }
            return vm.project.status;
        }

        function viewContributors() {
            $state.get('donations.list').data.projectId = vm.project._id;
            $state.go('donations.list');
        }

        function saveDonation(amount) {
            if (amount > 0) {
                vm.donation.projectId = vm.project._id;
                vm.donation.amount = amount;
                vm.donation.user = vm.project.user;

                if (vm.project.pledged > 0) {
                    vm.project.pledged = amount + vm.project.pledged;
                } else {
                    vm.project.pledged = amount;
                }

                vm.project.donations = vm.donation;

                if (vm.project.payment == 'creditcard') {
                    if (vm.project.user.credit_card !== undefined) {
                        project.paymentInfo = vm.project.user.credit_card;
                        vm.project.$pay();

                        $http.post('api/donations', vm.donation).
                        success(function (response) {
                            vm.contributorsCount += 1;
                            swangular.swal("", "", "success");
                            swangular.swal({   
                              title: 'Donation successful!',
                              text: "Thank you for donating",
                              type: 'success',
                              confirmButtonText: 'Continue' }).then(function(){
                                $window.location.href= $location.path();
                              });
                           
                        });
                    } else {
                        swangular.swal("Oops!", "You do not have a credit card!", "error");
                    }
                } else {
                    vm.project.$pay(testCallback, errorCallback);
                }

                project.user = vm.project.user;
                project.modePayment = vm.project.payment;

            } else {
                swangular.swal("Oops!", "Cannot donate zero or less!", "error");
            }
        }

        function testCallback(res) {
            $window.location.href = res.redirectUrl;
        }

        function errorCallback(res) {
            vm.error = res.data.message;
        }

        function startDateOnSetTime() {
            vm.$broadcast('start-date-changed');
        }

        function endDateOnSetTime() {
            vm.$broadcast('end-date-changed');
        }

        function startDateBeforeRender($dates) {
            if (vm.project.expiration) {
                var activeDate = moment(vm.project.expiration);

                $dates.filter(function (date) {
                    return date.localDateValue() >= activeDate.valueOf();
                }).forEach(function (date) {
                    date.selectable = false;
                });
            }
        }

        function endDateBeforeRender($view, $dates) {
            if (vm.project.created) {
                var activeDate = moment(vm.project.created).subtract(1, $view).add(1, 'minute');

                $dates.filter(function (date) {
                    return date.localDateValue() <= activeDate.valueOf();
                }).forEach(function (date) {
                    date.selectable = false;
                });
            }
        }

        // Remove existing Project
        function remove() {
            if ($window.confirm('Are you sure you want to delete?')) {
                vm.project.$remove($state.go('projects.list'));
            }
        }

        // Save Project
        function save(isValid) {
            if (!isValid) {
                vm.$broadcast('show-errors-check-validity', 'vm.form.projectForm');
                return false;
            }

            // TODO: move create/update logic to service
            if (vm.project._id) {
                vm.project.$update(successCallback, errorCallback);
            } else {
                vm.project.$save(successCallback, errorCallback);
            }


            function successCallback(res) {
                $state.go('projects.view', {
                    projectId: res._id
                });
            }

            function errorCallback(res) {
                vm.error = res.data.message;
            }
        }
    }
}());