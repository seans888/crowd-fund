'use strict';

/**
 * Module dependencies.
 */
var path = require('path'),
    mongoose = require('mongoose'),
    Project = mongoose.model('Project'),
    errorHandler = require(path.resolve('./modules/core/server/controllers/errors.server.controller')),
    _ = require('lodash'),
    multer = require('multer'),
    config = require(path.resolve('./config/config')),
    paypal = require('paypal-rest-sdk');


// paypal auth configuration
var configure = {
    port: 5000,
    api: {
        host: 'api.sandbox.paypal.com',
        port: '',
        client_id: 'AU7DNvyANX7HowttljYcNsZhIgh3sQwLnNGSC50L1OHXBZyoZ760mMLUrrF353VcwUIImKTEQy0WCiLh',
        client_secret: 'EPFL-pH_VDPLdgFsjdxbFlhzv4OI1Djh3SBRqw9RZaegyLkHiqAPS4tOGPr_P2Gnq-o4K1OAYCsCRuiU' // your paypal application secret id
    }
}
paypal.configure(configure.api);


/**
 * Create a Project
 */
exports.create = function (req, res) {
    var project = new Project(req.body);
    project.user = req.user;

    project.save(function (err) {
        if (err) {
            return res.status(400).send({
                message: errorHandler.getErrorMessage(err)
            });
        } else {
            res.jsonp(project);
        }
    });
};

/**
 * Show the current Project
 */
exports.read = function (req, res) {
    // convert mongoose document to JSON
    var project = req.project ? req.project.toJSON() : {};

    // Add a custom field to the Article, for determining if the current User is the "owner".
    // NOTE: This field is NOT persisted to the database, since it doesn't exist in the Article model.
    project.isCurrentUserOwner = req.user && project.user && project.user._id.toString() === req.user._id.toString();

    res.jsonp(project);
};

/**
 * Update a Project
 */
exports.update = function (req, res) {
    var project = req.project;

    project = _.extend(project, req.body);

    project.save(function (err) {
        if (err) {
            return res.status(400).send({
                message: errorHandler.getErrorMessage(err)
            });
        } else {
            res.jsonp(project);
        }
    });
};

/**
 * Delete an Project
 
exports.delete = function(req, res) {
  var project = req.project;

  project.remove(function(err) {
    if (err) {
      return res.status(400).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.jsonp(project);
    }
  });
};

*/

/**
 * Update project picture
 */
exports.uploadProjectPicture = function (req, res) {
    var project = req.project;
    var message = null;
    var upload = multer(config.uploads.profileUpload).single('newProfilePicture');
    var projectUploadFileFilter = require(path.resolve('./config/lib/multer')).profileUploadFileFilter;

    // Filtering to upload only images
    upload.fileFilter = projectUploadFileFilter;

    if (project) {
        upload(req, res, function (uploadError) {
            if (uploadError) {
                return res.status(400).send({
                    message: 'Error occurred while uploading profile picture'
                });
            } else {
                project.picture = config.uploads.profileUpload.dest + req.file.filename;

                project.save(function (saveError) {
                    if (saveError) {
                        return res.status(400).send({
                            message: errorHandler.getErrorMessage(saveError)
                        });
                    } else {
                        req.login(project, function (err) {
                            if (err) {
                                res.status(400).send(err);
                            } else {
                                res.json(project);
                            }
                        });
                    }
                });
            }
        });
    } else {
        res.status(400).send({
            message: 'User is not signed in'
        });
    }
};



/**
 * List of Projects
 */
exports.list = function (req, res) {
    Project.find().sort('-created').populate('user', 'displayName').exec(function (err, projects) {
        if (err) {
            return res.status(400).send({
                message: errorHandler.getErrorMessage(err)
            });
        } else {
            res.jsonp(projects);
        }
    });
};

/**
 * Project middleware
 */
exports.projectByID = function (req, res, next, id) {

    if (!mongoose.Types.ObjectId.isValid(id)) {
        return res.status(400).send({
            message: 'Project is invalid'
        });
    }

    Project.findById(id).populate('user', 'displayName').exec(function (err, project) {
        if (err) {
            return next(err);
        } else if (!project) {
            return res.status(404).send({
                message: 'No Project with that identifier has been found'
            });
        }
        req.project = project;
        next();
    });
};

exports.getPaypalResponse = function (req, res) {
    var paymentId = req.body.paymentId;
    var payerId = {
        payer_id: req.body.PayerID
    };
    console.log(paymentId);
    paypal.payment.execute(paymentId, payerId, function (error, payment) {

        if (error) {
            console.error(JSON.stringify(error));
        } else {
            if (payment.state == 'approved') {
                console.log('payment completed successfully');
            } else {
                console.log('payment not successful');
            }
        }
    });
}


exports.payNow = function (req, res) {

    var response = {};
    var payReq = {};
    // Build PayPal payment request

    console.log(req.body.modePayment);

    if (req.body.modePayment == 'paypal') {
        payReq = JSON.stringify({
            intent: 'sale',
            payer: {
                payment_method: 'paypal'
            },
            redirect_urls: {
                return_url: 'http://localhost:3000/projects/' + req.body._id + '/process',
                cancel_url: 'http://localhost:3000/projects/' + req.body._id + '/cancel'
            },
            transactions: [{
                amount: {
                    total: req.body.donations.amount,
                    currency: 'USD'
                },
                description: 'Donation of ' + req.body.donations.amount + 'for \n Project Name: ' + req.body.name
            }]
        });

        paypal.payment.create(payReq, function (error, payment) {
            if (error) {
                console.log('Error on Paypal payment');
                console.log(error);
            } else {
                if (payment.payer.payment_method === 'paypal') {
                    response.paymentId = payment.id;
                    var redirectUrl;
                    response.payment = payment;
                    console.log(payment);
                    for (var i = 0; i < payment.links.length; i++) {
                        var link = payment.links[i];
                        if (link.method === 'REDIRECT') {
                            redirectUrl = link.href;
                        }
                    }
                    response.redirectUrl = redirectUrl;
                }
            }
            /* 
             * Sending Back Paypal Payment response 
             */

            res.jsonp(response);
        });
    } else {
        payReq = JSON.stringify({
            intent: 'sale',
            payer: {
                payment_method: 'credit_card',
                funding_instruments: [{
                    credit_card: req.body.paymentInfo
                }]
            },
            transactions: [{
                amount: {
                    total: req.body.donations.amount,
                    currency: 'USD',
                    details: {
                        subtotal: req.body.donations.amount,
                        tax: '0.00',
                        shipping: '0.00'
                    }
                },
                description: 'Donation of ' + req.body.donations.amount + 'for \n Project Name: ' + req.body.name
            }]
        });

        paypal.payment.create(payReq, function (error, payment) {
            if (error) {
                response = error;
                console.log('error on execute');
            } else {
                response = payment;
                console.log("Create Payment Response");

            }

            /* 
             * Sending Back Paypal Payment response 
             */

            res.jsonp(response);
        });
    }

};