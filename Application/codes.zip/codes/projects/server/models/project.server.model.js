'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
    Schema = mongoose.Schema;

/**
 * Project Schema
 */
var ProjectSchema = new Schema({
    name: {
        type: String,
        default: '',
        required: 'Please fill Project name',
        trim: true
    },
    description: {
        type: String,
        default: '',
        required: 'Please fill Project description',
        trim: true
    },
    location: {
        type: String,
        default: '',
        required: 'Please fill Project location',
        trim: true
    },
    target: {
        type: Number,
        default: 10000,
        required: 'Please fill Project target fund',
        trim: true
    },
    pledged: {
        type: Number,
        trim: true,
        default: 0
    },
    created: {
        type: Date
    },
    expiration: {
        type: Date,
        required: 'Please fill Project expiration date',
    },
    status: {
        type: String,
        default: 'Ongoing',
    },
    picure: {
        type: String,
        default: 'modules/users/client/img/profile/default.png'
    }
});

mongoose.model('Project', ProjectSchema);