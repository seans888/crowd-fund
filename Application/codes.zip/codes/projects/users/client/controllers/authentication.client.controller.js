'use strict';

angular.module('users').controller('AuthenticationController', ['$scope', '$state', '$http', '$location', '$window', 'Authentication', 'PasswordValidator', 'swangular',
  function ($scope, $state, $http, $location, $window, Authentication, PasswordValidator, swangular) {
    $scope.authentication = Authentication;
    $scope.addCreditCard = false;
    $scope.popoverMsg = PasswordValidator.getPopoverMsg();
    $scope.creditCard = ['Visa', 'Mastercard', 'Amex'];

    // Get an eventual error defined in the URL query string:
    $scope.error = $location.search().err;

    // If user is signed in then redirect back home
    if ($scope.authentication.user) {
      $location.path('/');
    }
    $scope.credError = {};

    $scope.signup = function (isValid) {
      $scope.error = null;
      console.log('scopeCheck', $scope.credentials);
      var creds = $scope.credentials;
      var creditCard = null;
      var credErrors = [];

  
      if (creds != null){
        creditCard = creds.credit_card;
      }
      if(creditCard != null){
         credErrors = $scope.checkCreditCard(creditCard);
      }
      console.log('credErrors', credErrors);
      if(credErrors.indexOf('numberError') > -1){
        $scope.credError.numberCheck = true;
      }
      if(credErrors.indexOf('monthError') > -1){
        $scope.credError.monthError = true;

      }
      if(credErrors.indexOf('yearError') > -1){
        $scope.credError.yearError = true;
      }
      console.log($scope.credError.numberCheck);
      if (!isValid) {
        $scope.$broadcast('show-errors-check-validity', 'userForm');
        return false;
      }
      if(credErrors.length != 0 ){
        swal("Oops!", "Invalid Credit Card Information! Recheck Credit Card Number and Expiry Dates", "error");
        return false;
      }
      $http.post('/api/auth/signup', $scope.credentials).success(function (response) {
        // If successful we assign the response to the global user model
        $scope.authentication.user = response;

        // And redirect to the previous or home page
        $state.go($state.previous.state.name || 'home', $state.previous.params);
      }).error(function (response) {
        $scope.error = response.message;
      });
    };

  $scope.checkCreditCard = function(credit){
      console.log('function check');
      var errorArr = [];
      var number = credit.number;
      var expireMonth = credit.expire_month;
      var expireYear = credit.expire_year;


      if (number != null){
        var pattern = new RegExp("^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$");
         if(pattern.test(number) == false){
          console.log("numberError");
            errorArr.push('numberError');
         }
        }
      if (expireMonth != null){
        var pattern = new RegExp("^(0?[1-9]|1[012])$");
        if(pattern.test(expireMonth) == false){
          console.log("monthError");
          errorArr.push("monthError");
        }
      }
      if (expireYear != null){
        var pattern = new RegExp("^201[7-9]");
        if(pattern.test(expireYear) == false){
          console.log("yearError");
          errorArr.push("yearError");
        }
      }
      
      return errorArr;
    };
    $scope.signin = function (isValid) {
      $scope.error = null;
      
      if (!isValid) {
        $scope.$broadcast('show-errors-check-validity', 'userForm');

        return false;
      }

      $http.post('/api/auth/signin', $scope.credentials).success(function (response) {
        // If successful we assign the response to the global user model
        $scope.authentication.user = response;

        // And redirect to the previous or home page
        $state.go($state.previous.state.name || 'home', $state.previous.params);
      }).error(function (response) {
        $scope.error = response.message;
      });
    };

    // OAuth provider request
    $scope.callOauthProvider = function (url) {
      if ($state.previous && $state.previous.href) {
        url += '?redirect_to=' + encodeURIComponent($state.previous.href);
      }

      // Effectively call OAuth authentication route:
      $window.location.href = url;
    };

  }
]);
